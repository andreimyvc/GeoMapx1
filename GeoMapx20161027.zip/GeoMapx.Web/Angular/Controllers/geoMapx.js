﻿
var geoMapx = angular.module('geoMapx', []);

var xbaseController = function ($scope, $http) {
};

geoMapx.controller('xbaseController', xbaseController);

