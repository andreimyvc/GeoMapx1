﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GeoMapx.Web.Models
{
    public class Coordenada
    {
        public double longitude { get; set; }
        public double latitude { get; set; }
    }
}